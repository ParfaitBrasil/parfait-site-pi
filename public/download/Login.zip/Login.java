import javax.swing.*;

public class Login {
    public static void main(String[] args) {
        LoginFrame frame = new LoginFrame();
        frame.setTitle("Formulário de Login");
        frame.setVisible(true);
        frame.setSize(370, 500);
        frame.setLocationRelativeTo ( null );
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
    }
}