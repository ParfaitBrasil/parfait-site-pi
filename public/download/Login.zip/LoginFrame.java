import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

class LoginFrame extends JFrame implements ActionListener {
    Container container = getContentPane();
    JLabel userLabel = new JLabel("Usuário");
    JLabel passwordLabel = new JLabel("Senha");
    JTextField userTextField = new JTextField();
    JPasswordField passwordField = new JPasswordField();
    JButton loginButton = new JButton("Login");
    JButton resetButton = new JButton("Limpar");
    JCheckBox showPassword = new JCheckBox("Mostrar senha");

    LoginFrame() {
        setLayoutManager();
        setLocationAndSize();
        addComponentsToContainer();
        addActionEvent();
    }

    public void setLayoutManager() {
        container.setLayout(null);
    }

    public void setLocationAndSize() {
        userLabel.setBounds(50, 100, 100, 30);
        passwordLabel.setBounds(50, 170, 100, 30);
        userTextField.setBounds(150, 100, 150, 30);
        passwordField.setBounds(150, 170, 150, 30);
        showPassword.setBounds(150, 200, 150, 30);
        loginButton.setBounds(50, 250, 115, 40);
        resetButton.setBounds(185, 250, 115, 40);
    }

    public void addComponentsToContainer() {
        container.add(userLabel);
        container.add(passwordLabel);
        container.add(userTextField);
        container.add(passwordField);
        container.add(showPassword);
        container.add(loginButton);
        container.add(resetButton);
    }

    public void addActionEvent() {
        loginButton.addActionListener(this);
        resetButton.addActionListener(this);
        showPassword.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == loginButton) {
            String userText;
            String pwdText;
            userText = userTextField.getText();
            pwdText = passwordField.getText();
            User user = getAuthenticatedUser(userText, pwdText);
            if (user != null && user.error.equals("")) {
                JOptionPane.showMessageDialog(this,
                "Autentição realizada com sucesso: " + user.username,
                "Sucesso",
                JOptionPane.PLAIN_MESSAGE);
                userTextField.setText("");
                passwordField.setText("");
            } else if(user != null) {
                JOptionPane.showMessageDialog(this,
                user.error,
                "Erro, tente novamente",
                JOptionPane.ERROR_MESSAGE
                );
            }
        }
        if (e.getSource() == resetButton) {
            userTextField.setText("");
            passwordField.setText("");
        }
        if (e.getSource() == showPassword) {
            if (showPassword.isSelected()) {
                passwordField.setEchoChar((char) 0);
                showPassword.setText("Esconder senha");
            } else {
                passwordField.setEchoChar('*');
                showPassword.setText("Mostrar senha");
            }
        }
    }

    private User getAuthenticatedUser(String username, String password){
        User user = null;

        final String DB_URL = "jdbc:mysql://localhost:3306/piauth?serverTimezone=UTC";
        final String USERNAME = "root";
        final String PASSWORD = "";

        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);

            Statement stmt = connection.createStatement();
            String sqlUsername = "SELECT nome FROM usuarios WHERE nome=?";
            PreparedStatement preparedStatementUsername = connection.prepareStatement(sqlUsername);
            preparedStatementUsername.setString(1, username);

            ResultSet rsUsername = preparedStatementUsername.executeQuery();

            user = new User();

            if (rsUsername.next()) {
                user.username = rsUsername.getString("nome");
                user.error = "";

                String sqlPassword = "SELECT nome, senha FROM usuarios WHERE nome=? AND senha=?";
                PreparedStatement preparedStatementPassword = connection.prepareStatement(sqlPassword);
                preparedStatementPassword.setString(1, username);
                preparedStatementPassword.setString(2, password);

                ResultSet rsPassword = preparedStatementPassword.executeQuery();

                if(rsPassword.next()) {
                    user.password = rsPassword.getString("senha");
                } else {
                    user.error = "Senha incorreta para o usuário " + user.username;
                }
            } else {
                user.error = "Nome de usuário incorreto";
            }

            stmt.close();
            connection.close();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }

        return user;
    }
}